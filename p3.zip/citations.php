<?php include('header.php'); ?>
        <section class="panel">
          <h1 class="full"><span class="highlight">Credit</span> where its due.</h1>

          <p>Adams, V. (n.d.). <em>Muli.</em> Retrieved from https://fonts.google.com/specimen/Muli</p>
          <p>Diogo, P. (2015, June 16). <em>Get the browser viewport dimensions with JavaScript.</em> Retrieved from https://stackoverflow.com/questions/1248081/get-the-browser-viewport-dimensions-with-javascript?utm_medium=organic&utm_source=google_rich_qa&utm_campaign=google_rich_qa</p>
          <p>Khan, M. (2018, February 13). <em>Hover effect : expand bottom border.</em> Retrieved from https://stackoverflow.com/questions/28623446/hover-effect-expand-bottom-border</p>
          <p>Marquizzo (2017, May 19). <em>How to get height of entire document with JavaScript?</em> Retrieved from https://stackoverflow.com/questions/1145850/how-to-get-height-of-entire-document-with-javascript</p>
          <p>Sorensen, C. (n.d.). <em>Playfair Display.</em> Retrieved from https://fonts.google.com/specimen/Playfair+Display</p>
          <p>W3schools (n.d.). <em>HTML DOM scrollTop Property.</em> Retrieved from https://www.w3schools.com/jsreF/tryit.asp?filename=tryjsref_onscroll3</p>
          <p>Zengabor. (2018, March 1). <em>Zenscroll.</em> Retrieved from https://github.com/zengabor/zenscroll</p>

        </section><!--end panel-->

<?php include('footer.php'); ?>
