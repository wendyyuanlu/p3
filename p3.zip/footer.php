      </main>

      <!-- SharePoint
      SAP Conversations
      MakerLabs
      Seeing AI
      Travelocity -->

      <script src="js/main.js"></script>
      <script src="js/zenscroll-min.js"></script>

      <footer>
        <!-- <p class="social">
          <a href="http://flickr.com/photos/heywendylu" onclick="target='_blank'"><img src="img/flickr1.png" alt="Flickr"></a>
          <a href="http://flickr.com/photos/heywendylu" onclick="target='_blank'"><img src="img/flickr1.png" alt="Flickr"></a>
          <a href="http://instagram.com/heywendylu" onclick="target='_blank'"><img src="img/instagram1.png" alt="Instagram"></a>
        </p> -->
        <p><a href="styleguide.php">Styleguide</a> &nbsp;&nbsp; | &nbsp;&nbsp; <a href="citations.php">Citations</a> &nbsp;&nbsp; | &nbsp;&nbsp; <a href="https://github.com/wendyyuanlu/p3" onclick="target='_blank'">Github</a></p>
        <p>&copy; 2018 Wendy Lu. All rights reserved.</p>
      </footer>

    </div> <!--end container-->

    <!-- <script src="js/main.js"></script> -->

  </body>

</html>
